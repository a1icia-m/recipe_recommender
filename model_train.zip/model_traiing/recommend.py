import os
import json
import faiss
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer, util
from rapidfuzz import fuzz
from transformers import pipeline

classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")

query = "I want something not too sugary but high in protein"
labels = ["low sugar", "high protein", "low fat", "low calorie"]

result = classifier(query, labels)
print(result)

#Set model and file paths
model = SentenceTransformer("all-MiniLM-L6-v2")

recipe_path = r"C:\Users\alici\Desktop\code\misc\recipe_recommender\data\recipe_test_clean.json"
embedding_path = r"C:\Users\alici\Desktop\code\misc\recipe_recommender\outputs\recipe_embeddings.npy"
index_path = r"C:\Users\alici\Desktop\code\misc\recipe_recommender\outputs\recipe_index.faiss"
macros_embedding_path = r"C:\Users\alici\Desktop\code\misc\recipe_recommender\outputs\macros_embeddings.npy"

#load in recipe data
with open(recipe_path, "r", encoding="utf-8") as f:
    recipes = json.load(f)
recipe_text = [", ".join(r["RecipeIngredientParts"]) for r in recipes]

#If first time running, create file, else fetch pre-exisitng embeddings from the file
if os.path.exists(embedding_path) and os.path.exists(index_path):
    embeddings = np.load(embedding_path)
    index = faiss.read_index(index_path)
else:
    embeddings = model.encode(recipe_text, batch_size=256, show_progress_bar=True).astype("float32")
    np.save(embedding_path, embeddings)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)
    faiss.write_index(index, index_path)

#Embed macro information
macros_filter = {
    "high protein": {"min_protein": 10},
    "low sugar": {"max_sugar": 10},
    "low calorie": {"max_calories": 400},
    "high fiber": {"min_fiber": 5},
    "low fat": {"max_fat": 10},
    "high carb": {"min_carbs": 30}
}
macros_keys = list(macros_filter.keys())

if os.path.exists(macros_embedding_path):
    macros_embeddings = np.load(macros_embedding_path)
else:
    macros_embeddings = model.encode(macros_keys)
    np.save(macros_embedding_path, macros_embeddings)

#Search for most relvant recipes
def search(query_ingredients, topk=50):
    query_vector = model.encode([", ".join(query_ingredients)])[0].astype("float32")
    query_vector = np.array(query_vector).reshape(1, -1)
    distances, indices = index.search(query_vector, topk)
    return [recipes[i] for i in indices[0]]

#Smart search so it works with typos
def smart_search(user_input, fuzzy_threshold=65, semantic_threshold=0.7):
    tokens = [t.strip().lower() for t in user_input.split(",")]
    parsed_filters = {}
    ingredients = []
    for token in tokens:
        fuzzy_match = next((key for key in macros_filter if fuzz.ratio(token, key) >= fuzzy_threshold), None)
        if fuzzy_match:
            parsed_filters.update(macros_filter[fuzzy_match])
            continue
        query_emb = model.encode([token])[0]
        sim_scores = util.cos_sim(query_emb, macros_embeddings)[0]
        best_idx = sim_scores.argmax()
        if sim_scores[best_idx] >= semantic_threshold:
            matched_macro = macros_keys[best_idx]
            parsed_filters.update(macros_filter[matched_macro])
        else:
            ingredients.append(token)
    return ingredients, parsed_filters

def apply_nutrition_filters(results, filters):
    FIELD_MAP = {
        "sugar": "SugarContent",
        "protein": "ProteinContent",
        "calories": "Calories",
        "fiber": "FiberContent",
        "fat": "FatContent",
        "carbs": "CarbohydrateContent"
    }

    def passes_constraints(recipe):
        for key, value in filters.items():
            base_field = key.replace("min_", "").replace("max_", "")
            recipe_field = FIELD_MAP.get(base_field, base_field)  # default to original

            recipe_val = recipe.get(recipe_field)
            if recipe_val is None:
                return False

            if key.startswith("min_") and recipe_val < value:
                return False
            if key.startswith("max_") and recipe_val > value:
                return False

        return True

    return [r for r in results if passes_constraints(r)]

#Test on query
query = "egg, avocado, low calories, high potien"
ingredients, filters = smart_search(query)
print(filters)
results = search(ingredients, topk=50)

filtered_results = apply_nutrition_filters(results, filters)

columns = ["Name", "Description", "RecipeIngredientParts", "Calories", "ProteinContent"]
to_print = [{col: r.get(col) for col in columns} for r in filtered_results[:5]]
print(*to_print, sep ='\n')