from fastapi import FastAPI, Query
from models.recommend import smart_search, apply_nutrition_filters, search
from typing import List
import pandas as pd

app = FastAPI()

@app.get("/")
def root():
    return {"message": "It works!"}

@app.get("/recommend")
def recommend(query: str = Query(..., description="e.g. 'egg, avocado, high protein, low sugar'")):
    # 1. Smart parse
    ingredients, filters = smart_search(query)

    # 2. Vector search
    results = search(ingredients, topk=50)

    # 3. Filter by nutrition
    filtered = apply_nutrition_filters(results, filters)

    # 4. Format key columns
    columns = ["Name", "Description", "RecipeIngredientParts", "Calories", "FatContent", "SaturatedFatContent", "CholesterolContent",
        "SodiumContent", "CarbohydrateContent", "FiberContent", "SugarContent",
        "ProteinContent"]
    output = [{col: r.get(col) for col in columns} for r in filtered[:5]]

    return {"ingredients": ingredients, "filters": filters, "recipes": output}



# #load in api key
# import os
# from dotenv import load_dotenv

# load_dotenv()
# api_key = os.getenv("SPOONACULAR_API_KEY")

# print("Loaded API key:", api_key[:5] + "...")

# import requests

# response = requests.get(
#     "https://api.spoonacular.com/recipes/findByIngredients",
#     params={"ingredients": "egg,tomato", "number": 5, "apiKey": api_key}
# )
# print(response.json())

